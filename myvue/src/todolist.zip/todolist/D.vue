<template>
  <div class="about">
    <footer>
      Copyright &copy; 2014 todolist.cn <a href="javascript:clear();">clear</a>
    </footer>
  </div>
</template>
<script>
export default {
  name:"about",
  data(){
    return{

    }
  },
}
</script>
<style >
footer {
  color: #666;
  font-size: 14px;
  text-align: center;
}
footer a {
  color: #666;
  text-decoration: none;
  color: #999;
}
@media screen and (max-device-width: 620px) {
  section {
    width: 96%;
    padding: 0 2%;
  }
}
@media screen and (min-width: 620px) {
  section {
    width: 600px;
    padding: 0 10px;
  }
}
</style>