<template>
  <div class="home">
    <B></B>
    <C></C>
    <D></D>
  </div>
</template>

<script>
import D from './D'
import B from './B'
import C from './C'
export default {
  name: 'home',
     data(){
       return{
          
       }
     },
     components:{
       D,
       B,
       C,
     }
}
</script>
<style >
  
</style>