<template>
  <div class="before">
    <!-- 发布前 -->
    <section>
      <h2 onclick="save()">正在进行 <span id="todocount">{{arr.length}}</span></h2>
      <ol id="todolist" class="demo-box">
          <li v-for="(item,index) in arr" :key="index">
              <input type="checkbox" v-model="item.check" @click="change(index)">
              <p>{{item.inp}}</p>
               <a href="" @click='del(index)'></a>
          </li>
      </ol>
      <h2>已经完成 <span id="donecount"></span></h2>
      <ul id="donelist">
           <li v-for="(item,index) in Twoarr" :key="index">
              <input type="checkbox" v-model="item.check" @click="xiu(index)">
              <p>{{item.inp}}</p>
               <a href="" @click='del(index)'></a>
          </li>
      </ul>
    </section>
  </div>
</template>

<script>
export default {
    name:"before",
    data(){    
        return{
            //   inp:'',
            //   check:"",
              arr:[{inp:'十三',check:false},{inp:"十四",check:false}],
              Twoarr:[]
        }
    },
   created(){
        this.$bus.$on("ly",(val)=>{
           this.arr.push(val)
           console.log(this.arr);
        })
   },
   methods: {
       change(index){
            // this.arr   this.Twoarr
            this.arr[index]
            console.log(this.arr[index]);
            this.Twoarr.push(this.arr[index])
            this.arr.splice(index,1)
       },
       xiu(index){
           this.Twoarr[index];
           console.log(this.Twoarr[index]);
           this.arr.push(this.Twoarr[index])
           this.Twoarr.splice(index,1)
       },
     del(index){
         this.arr.splice(index,1)
     }
   },
};
</script>
  
<style>
section {
  margin: 0 auto;
}
label {
  float: left;
  width: 100px;
  line-height: 50px;
  color: #ddd;
  font-size: 24px;
  cursor: pointer;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
}
header input {
  float: right;
  width: 60%;
  height: 24px;
  margin-top: 12px;
  text-indent: 10px;
  border-radius: 5px;
  box-shadow: 0 1px 0 rgba(255, 255, 255, 0.24),
    0 1px 6px rgba(0, 0, 0, 0.45) inset;
  border: none;
}
input:focus {
  outline-width: 0;
}
h2 {
  position: relative;
}
span {
  position: absolute;
  top: 2px;
  right: 5px;
  display: inline-block;
  padding: 0 5px;
  height: 20px;
  border-radius: 20px;
  background: #e6e6fa;
  line-height: 22px;
  text-align: center;
  color: #666;
  font-size: 14px;
}
ol,
ul {
  padding: 0;
  list-style: none;
}
li input {
  position: absolute;
  top: 2px;
  left: 10px;
  width: 22px;
  height: 22px;
  cursor: pointer;
}
p {
  margin: 0;
}
li p input {
  top: 3px;
  left: 40px;
  width: 70%;
  height: 20px;
  line-height: 14px;
  text-indent: 5px;
  font-size: 14px;
}
li {
  height: 32px;
  line-height: 32px;
  background: #fff;
  position: relative;
  margin-bottom: 10px;
  padding: 0 45px;
  border-radius: 3px;
  border-left: 5px solid #629a9c;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.07);
}
ol li {
  cursor: move;
}
ul li {
  border-left: 5px solid #999;
  opacity: 0.5;
}
li a {
  position: absolute;
  top: 2px;
  right: 5px;
  display: inline-block;
  width: 14px;
  height: 12px;
  border-radius: 14px;
  border: 6px double #fff;
  background: #ccc;
  line-height: 14px;
  text-align: center;
  color: #fff;
  font-weight: bold;
  font-size: 14px;
  cursor: pointer;
}
</style>
